@extends('template.master')
@section('content')

  <div class="topdesktop"></div><br>
    <!-- breadcrumb -->
    <div class="container">
        <div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
            <a href="{{ route('home') }}" class="stext-109 cl8 hov-cl1 trans-04">
                Home
                <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
            </a>

            

            <span class="stext-109 cl4">
                {{ ucwords(Str::lower($produk->nm_produk)) }}
            </span>
        </div>
    </div>
    <section class="sec-product-detail bg0 p-t-65 p-b-60" style="background-color: #ECE8E1">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-7 p-b-30">
                    <div class="p-l-25 p-r-30 p-lr-0-lg">
                        <div class="wrap-slick3 flex-sb flex-w">
                            <div class="wrap-slick3-dots"></div>
                            <div class="wrap-slick3-arrows flex-sb-m flex-w"></div>

                            <div class="slick3 gallery-lb">
                                

                                <div class="item-slick3"
                                    data-thumb="http://127.0.0.1:8000/assets/uploads/{{ $produk->foto }}">
                                    <div class="wrap-pic-w pos-relative">
                                        <img src="http://127.0.0.1:8000/assets/uploads/{{ $produk->foto }}"
                                            alt="IMG-PRODUCT">

                                        <a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04"
                                            href="http://127.0.0.1:8000/assets/uploads/{{ $produk->foto }}">
                                            <i class="fa fa-expand"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                  
                <div class="col-md-6 col-lg-5 p-b-30">
                    <div class="p-r-50 p-t-5 p-lr-0-lg">
                        <h4 class="mtext-105 cl2 js-name-detail p-b-14">
                            {{ $produk->nm_produk }}
                        </h4>

                        <span class="mtext-106 cl2">
                            Rp {{ number_format($produk->harga, 0) }}
                        </span>

                        <p class="stext-102 cl3 p-t-23">
                            {!! $produk->deskripsi !!}
                        </p>

                        <!--  -->
                        <div class="p-t-33">


                            <div class="flex-w p-b-10">
                                <div class="size-204 flex-w flex-m respon6-next">
                                    @php
                                        $harga = DB::table('tb_harga')
                                            ->select('tb_harga.*', 'tb_distribusi.*')
                                            ->join('tb_distribusi', 'tb_harga.id_distribusi', '=', 'tb_distribusi.id_distribusi')
                                            ->where('id_produk', $produk->id_produk)
                                            ->get();
                                    @endphp
                                    <div class="middle">
                                    <p>
                                        <a class="btn btn-primary mr-4" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1"><i class="fa fa-shopping-cart"></i> Add To Cart</a>            
                                      </p>
                                    </div>
                                          <div class="collapse multi-collapse" id="multiCollapseExample1">
                                            @foreach ($harga as $h)
                                            @php
                                                if (Str::lower($h->nm_distribusi) == 'shopee') {
                                                    $icon = 'https://img.icons8.com/color/48/000000/shopee.png';
                                                    $w = 48;
                                                } elseif (Str::lower($h->nm_distribusi) == 'tokopedia') {
                                                    $icon = 'https://www.freepnglogos.com/uploads/logo-tokopedia-png/logo-tokopedia-15.png';
                                                    $w = 46;
                                                }
                                            @endphp
    
                                            <a href="{{ $h->link }}" target="blank" class="mr-2">
                                                <img src="{{ $icon }}" width="{{ $w }}" />
                                            </a>
                                        @endforeach
                                         </div>
                                    

                                </div>
                                
                            </div>
                        </div>

                        <!--  -->

                    </div>
                </div>
            </div>

            <div class="bor10 m-t-50 p-t-43 p-b-40">
                <!-- Tab01 -->
                <div class="tab01">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item p-b-10">
                            <a class="nav-link active" data-toggle="tab" href="#description" role="tab">Product Video</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content p-t-43">
                        <!-- - -->
                        <div class="tab-pane fade show active" id="description" role="tabpanel">
                            <div class="how-pos2 p-lr-15-md">
                                <div class="row justify-content-center">
                                    @php
                                            $video = DB::table('tb_video')->join('tb_produk', 'tb_produk.id_produk', '=', 'tb_video.id_produk')->where('tb_video.id_produk', $produk->id_produk)->get();
                                        @endphp
                                        @foreach ($video as $v)
                                        <div class="col-lg-6 col-11 mb-2">           
                                            <div class="embed-responsive embed-responsive-16by9">
                                                <iframe width="420" height="315" allowfullscreen class="embed-responsive-item"
                                                    src="https://www.youtube.com/embed/{{Str::substr($v->link_video, 32, 20)}}">
                                                </iframe>
                                            </div>
                                            </div>
                                        @endforeach
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
