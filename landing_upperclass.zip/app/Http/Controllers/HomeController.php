<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index()
    {
        $data = [
            'title' => 'Home',
            'kategori' => DB::table('tb_kategori')->get(),
            'banner' => DB::table('tb_banner')->get()
        ];
        return view('welcome',$data);
    }
}
