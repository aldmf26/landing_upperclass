
<?php $__env->startSection('content'); ?>
    <!-- Title page -->
	<section class="bg-img1 txt-center p-lr-15 p-tb-92" style="background-image: url('<?php echo e(asset('assets')); ?>/images/bg-01.jpg');">
		<h2 class="ltext-105 cl0 txt-center">
			Contact
		</h2>
	</section>	


	<!-- Content page -->
	<section class="bg0 p-t-104 p-b-50">
		<div class="container justify-content-center">
			<div class="flex-w flex-tr justify-content-center">
				<div class="size-210 bor10 p-lr-70 p-t-55 p-b-70 p-lr-15-lg w-full-md">
					<form action="<?php echo e(route('kirim')); ?>" method="post">
						<?php echo csrf_field(); ?>
						<h4 class="mtext-105 cl2 txt-center p-b-30">
							Send Us A Message
						</h4>

						<div class="bor8 m-b-20 how-pos4-parent">
							<input class="stext-111 cl2 plh3 size-116 p-l-62 p-r-30" type="text" name="email" placeholder="Your Email Address">
							<img class="how-pos4 pointer-none" src="<?php echo e(asset('assets')); ?>/images/icons/icon-email.png" alt="ICON">
						</div>

						<div class="bor8 m-b-30">
							<textarea class="stext-111 cl2 plh3 size-120 p-lr-28 p-tb-25" name="msg" placeholder="How Can We Help?"></textarea>
						</div>

						<button class="flex-c-m stext-101 cl0 size-121 bg3 bor1 hov-btn3 p-lr-15 trans-04 pointer">
							Submit
						</button>
					</form>
				</div>
				</center>

				<!--<div class="size-210 bor10 flex-w flex-col-m p-lr-93 p-tb-30 p-lr-15-lg w-full-md">-->
				<!--	<div class="flex-w w-full p-b-42">-->
				<!--		<span class="fs-18 cl5 txt-center size-211">-->
				<!--			<span class="lnr lnr-map-marker"></span>-->
				<!--		</span>-->

				<!--		<div class="size-212 p-t-2">-->
				<!--			<span class="mtext-110 cl2">-->
				<!--				Address-->
				<!--			</span>-->

				<!--			<p class="stext-115 cl6 size-213 p-t-18">-->
				<!--				Ig: @orchard.upperclassnail <br>-->
				<!--				Jl Ks Tubun No.28B-D Banjarmasin 70246-->
				<!--			</p>-->
				<!--		</div>-->
				<!--	</div>-->

				<!--	<div class="flex-w w-full p-b-42">-->
				<!--		<span class="fs-18 cl5 txt-center size-211">-->
				<!--			<span class="lnr lnr-phone-handset"></span>-->
				<!--		</span>-->

				<!--		<div class="size-212 p-t-2">-->
				<!--			<span class="mtext-110 cl2">-->
				<!--				Contact Us-->
				<!--			</span>-->

				<!--			<p class="stext-115 cl1 size-213 p-t-18">-->
				<!--				+62 811 5188778 / +62 811 5088881-->
				<!--			</p>-->
				<!--		</div>-->
				<!--	</div>-->

				<!--	<div class="flex-w w-full">-->
				<!--		<span class="fs-18 cl5 txt-center size-211">-->
				<!--			<span class="lnr lnr-envelope"></span>-->
				<!--		</span>-->

				<!--		<div class="size-212 p-t-2">-->
				<!--			<span class="mtext-110 cl2">-->
				<!--				Email-->
				<!--			</span>-->

				<!--			<p class="stext-115 cl1 size-213 p-t-18">-->
				<!--				upperclass.indonesia@gmail.com-->
				<!--			</p>-->
				<!--		</div>-->
				<!--	</div>-->
				<!--</div>-->
			</div>
		</div>
	</section>	
	
	
	<!-- Map -->
	<div class="text-center p-b-50">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15932.325766508655!2d114.58366096977537!3d-3.3300561999999974!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2de423df74278031%3A0x6e19d873632f2f73!2sOrchard%20Beauty%20Studio!5e0!3m2!1sid!2sid!4v1646968737573!5m2!1sid!2sid" width="1100" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<script>
		Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: "<?php echo e(Session::get('sukses')); ?>"
        });
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/kontak/kontak.blade.php ENDPATH**/ ?>