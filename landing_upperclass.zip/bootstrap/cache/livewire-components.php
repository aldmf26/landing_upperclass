<?php return array (
  'post-data' => 'App\\Http\\Livewire\\PostData',
);