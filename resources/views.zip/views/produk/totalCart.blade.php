<div id="getTotal">
    <div class="wrap-num-product flex-w m-l-auto m-r-0">
        <div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m kurangCart" id="" qty="1">
            <a href="#" class="kurangCart" ><i class="fs-16 zmdi zmdi-minus"></i></a>
        </div>

        <input class="mtext-104 cl3 txt-center num-product" id="iQty" type="number" min="0" name="num-product1" value="1">

        <div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m tambahCart" id="" qty="1">
            <a href="#" class="tambahCart" ></a><i class="fs-16 zmdi zmdi-plus"></i>
        </div>
        
    </div>
</div>