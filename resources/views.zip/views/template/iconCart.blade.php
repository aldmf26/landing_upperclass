<div class="icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti" id="notif" data-notify="{{ Cart::count(); }}">
    <a href="{{ route('shopingCart') }}"><i class="zmdi zmdi-shopping-cart text-light"></i></a>
</div>