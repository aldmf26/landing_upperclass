@extends('template.master')
@section('content')

<div class="bg0 m-t-30 p-b-90 topproduk" style="background-color: #ECE8E1;">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 mb-2">
                <center>
                    <i class="zmdi zmdi-account mt-5" style="font-size:130px; color:#8C2824; align:text-center;"></i><br>
                    <H1 style="font-size:25px; color:#8C2824; font-weight: 900;">CREATE A STORE ACCOUNT</H1>
                </center>
            </div>          
            <div class="col-lg-7">
                <img width="100%" src="http://127.0.0.1:1111/assets/uploads/howLogin.png" alt="">
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-5 mb-2">
                <center>
                    <i class="zmdi zmdi-pin-account mt-5" style="font-size:130px; color:#8C2824; align:text-center;"></i><br>
                    <H1 style="font-size:25px; color:#8C2824; font-weight: 900;">FILL IN YOUR DATA AND ADDRESS</H1>
                </center>
            </div>          
            <div class="col-lg-7">
                <img width="100%" src="http://127.0.0.1:1111/assets/uploads/registerHow.png" alt="">
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-5 mb-2">
                <center>
                <i class="zmdi zmdi-shopping-cart mt-5" style="font-size:130px; color:#8C2824; align:text-center;"></i><br>
                <H1 style="font-size:25px; color:#8C2824; font-weight: 900;">ADD THEM TO CART</H1>
                </center>
            </div>          
            <div class="col-lg-7">
                <img width="100%" src="http://127.0.0.1:1111/assets/uploads/addHow.png" alt="">
            </div>
        </div>
    </div>
</div>

@endsection