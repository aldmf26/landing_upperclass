
<?php $__env->startSection('content'); ?>
  <div class="topdesktop"></div><br>
    <!-- breadcrumb -->
    
    <section class="sec-product-detail bg0 p-t-65 p-b-60" style="background-color: #ECE8E1">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-7 p-b-30">
                    <div class="p-l-25 p-r-30 p-lr-0-lg">
                        <div class="wrap-slick3 flex-sb flex-w">
                            <div class="wrap-slick3-dots"></div>
                            <div class="wrap-slick3-arrows flex-sb-m flex-w"></div>

                            <div class="slick3 gallery-lb">
                                

                                <div class="item-slick3"
                                    data-thumb="http://127.0.0.1:1111/assets/uploads/<?php echo e($produk->foto); ?>">
                                    <div class="wrap-pic-w pos-relative">
                                        <img src="http://127.0.0.1:1111/assets/uploads/<?php echo e($produk->foto); ?>"
                                            alt="IMG-PRODUCT">

                                        <a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04"
                                            href="http://127.0.0.1:1111/assets/uploads/<?php echo e($produk->foto); ?>">
                                            <i class="fa fa-expand"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                  
                <div class="col-md-6 col-lg-5 p-b-30">
                    <div class="p-r-50 p-t-5 p-lr-0-lg">
                        <h4 class="mtext-105 cl2 js-name-detail p-b-14">
                            <?php echo e($produk->nm_produk); ?>

                        </h4>
                        <span class="mtext-106 cl2">
                            Rp <?php echo e(number_format($produk->harga, 0)); ?>

                        </span><br>
                        <span class="mtext-102"><?php echo e($produk->gr); ?>g</span>

                        <p class="stext-102 cl3 p-t-23">
                            <?php echo $produk->deskripsi; ?>

                        </p>

                        <!--  -->
                        <div class="p-t-33">


                            <div class="flex-w p-b-10">
                                <div class="size-200 flex-w flex-m respon6-next">
                                    <?php
                                        $harga = DB::table('tb_harga')
                                            ->select('tb_harga.*', 'tb_distribusi.*')
                                            ->join('tb_distribusi', 'tb_harga.id_distribusi', '=', 'tb_distribusi.id_distribusi')
                                            ->where('id_produk', $produk->id_produk)
                                            ->get();
                                    ?>
                                    <div class="middle">
                                    <p>
                                        <a class="btn btn-primary mr-4" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Add To Cart</a>            
                                      </p>
                                    </div>
                                          <div class="collapse multi-collapse" id="multiCollapseExample1">
                                            via :
                                            <a href="#" qty="1" gr="<?php echo e($produk->gr); ?>" img="<?php echo e($produk->foto); ?>" price="<?php echo e($produk->harga); ?>" name="<?php echo e($produk->nm_produk); ?>" id_produk="<?php echo e($produk->id_harga); ?>" id_user="<?php echo e(@Auth::user()->id == '' ? '' : Auth::user()->id); ?>" class="mr-2 btn_to_cart">
                                                <img src="<?php echo e(asset('assets')); ?>/images/icons/cart.png" width="48" />
                                            </a>
                                            <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                if (Str::lower($h->nm_distribusi) == 'shopee') {
                                                    $icon = 'https://img.icons8.com/color/48/000000/shopee.png';
                                                    $w = 48;
                                                } elseif (Str::lower($h->nm_distribusi) == 'tokopedia') {
                                                    $icon = 'https://www.freepnglogos.com/uploads/logo-tokopedia-png/logo-tokopedia-15.png';
                                                    $w = 46;
                                                }
                                            ?>
    
                                            <a href="<?php echo e($h->link); ?>" target="blank" class="mr-2">
                                                <img src="<?php echo e($icon); ?>" width="<?php echo e($w); ?>" />
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </div>
                                    

                                </div>
                                
                            </div>
                        </div>

                        <!--  -->

                    </div>
                </div>
            </div>

            <div class="bor10 m-t-50 p-t-43 p-b-40">
                <!-- Tab01 -->
                <div class="tab01">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item p-b-10">
                            <a class="nav-link active" data-toggle="tab" href="#description" role="tab">Product Video</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content p-t-43">
                        <!-- - -->
                        <div class="tab-pane fade show active" id="description" role="tabpanel">
                            <div class="how-pos2 p-lr-15-md">
                                <div class="row justify-content-center">
                                    <?php
                                            $video = DB::table('tb_video')->join('tb_produk', 'tb_produk.id_produk', '=', 'tb_video.id_produk')->where('tb_video.id_produk', $produk->id_produk)->get();
                                        ?>
                                        <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6 col-11 mb-2">           
                                            <div class="embed-responsive embed-responsive-16by9">
                                                <iframe width="420" height="315" allowfullscreen class="embed-responsive-item"
                                                    src="https://www.youtube.com/embed/<?php echo e(Str::substr($v->link_video, 32, 20)); ?>">
                                                </iframe>
                                            </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Related Products -->
	<section class="sec-relate-product bg0 p-t-45 p-b-105" style="background-color: #ECE8E1">
		<div class="container">
			<div class="p-b-45">
				<h3 class="ltext-106 cl5 txt-center">
					Related Products
				</h3>
			</div>

			<!-- Slide2 -->
			<div class="wrap-slick2">
				<div class="slick2">
                        <?php
                            $pr = DB::table('tb_produk')
                                    ->join('tb_kategori', 'tb_produk.id_kategori', '=', 'tb_kategori.id_kategori')
                                    ->join('tb_satuan', 'tb_produk.id_satuan', '=', 'tb_satuan.id_satuan')
                                    ->join('tb_harga', 'tb_produk.id_produk', '=', 'tb_harga.id_produk')
                                    ->where('tb_kategori.id_kategori', $produk->id_kategori)
                                    ->groupBy('tb_harga.id_produk')
                                    ->get();
                                   
                        ?>
                    <?php $__currentLoopData = $pr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                     
					<div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
						<!-- Block2 -->
						<div class="block2">
							<div class="block2-pic hov-img0">
                                <a href="<?php echo e(route('detail', ['id_produk' => $p->id_produk])); ?>" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                                    <img src="http://127.0.0.1:1111/assets/uploads/<?php echo e($p->foto); ?>" alt="IMG-PRODUCT">
                                </a>
							</div>

							<div class="block2-txt flex-w flex-t p-t-14">
								<div class="block2-txt-child1 flex-col-l ">
									<a href="<?php echo e(route('detail', ['id_produk' => $p->id_produk])); ?>" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
										<?php echo e(ucwords(Str::lower($p->nm_produk))); ?>

									</a>

									<span class="stext-105 cl3">
										<?php echo e(number_format($p->harga, 0)); ?>

									</span>
								</div>
							</div>
						</div>
					</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.btn_to_cart', function(){
                var id_user = $(this).attr('id_user')
                var id_produk = $(this).attr('id_produk')
                var price = $(this).attr('price')
                var name = $(this).attr('name')
                var qty = $(this).attr('qty')
                var img = $(this).attr('img')
                var gr = $(this).attr('gr')
         
                $.ajax({
                    url : "<?php echo e(route('addToCart')); ?>",
                    method : 'GET',
                    data : {
                        id_user : id_user,
                        id_produk : id_produk,
                        price : price,
                        name : name,
                        qty : qty,
                        img : img,
                        gr : gr,
                    },
                    success:function(data) {
                        if(data == 'berhasil') {
                            Swal.fire({
                            position: 'inherit',
                            icon: 'success',
                            title: 'Berhasil Tambah Cart',
                            showConfirmButton: false,
                            timer: 1500
                            })
                        }
                    }
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/produk/detail.blade.php ENDPATH**/ ?>