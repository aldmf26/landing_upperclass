
<?php $__env->startSection('content'); ?>
    

    <!-- Product -->
    <div class="bg0 m-t-30 p-b-140 topproduk" style="background-color: #ECE8E1;">
        <div class="container" >
            <?php
                foreach ($lokasi as $l) {
                    if (request()->id_lokasi == $l->id_lokasi) {
                        $lok = $l->nm_lokasi;
                    }
                }
            ?>
            <div class="flex-w flex-sb-m p-b-52">
                <h3 class="ltext-105 cl5 txt-center respon1">
                    <?php echo e($lok); ?>

                </h3>
                <div class="flex-w flex-l-m filter-tope-group m-tb-10">
                    <a href="<?php echo e(route('produk', ['id_lokasi' => Request::get('id_lokasi')])); ?>">
                        <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5 <?php echo e(Request::get('kategori') == '' ? 'how-active1' : ''); ?>" data-filter="*">
                            All Products
                        </button>
                    </a>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('produk')); ?>?kategori=<?php echo e($k->id_kategori); ?>&id_lokasi=<?php echo e(Request::get('id_lokasi')); ?>" class="<?php echo e(Request::get('kategori') == $k->id_kategori ? 'how-active1' : ''); ?> stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
                            data-filter=".<?php echo e(Str::lower($k->nm_kategori)); ?>">
                            <?php echo e(ucwords(Str::lower($k->nm_kategori))); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="flex-w flex-c-m m-tb-10">
                    

                    <div class="flex-c-m stext-106 cl6 size-105 bor4 pointer hov-btn3 trans-04 m-tb-4 js-show-search">
                        <i class="icon-search cl2 m-r-6 fs-15 trans-04 zmdi zmdi-search"></i>
                        <i class="icon-close-search cl2 m-r-6 fs-15 trans-04 zmdi zmdi-close dis-none"></i>
                        Search
                    </div>
                </div>

                <!-- Search product -->
                <div class="dis-none panel-search w-full p-t-10 p-b-15">
                    <div class="bor8 dis-flex p-l-15">
                        <button class="size-113 flex-c-m fs-16 cl2 hov-cl1 trans-04">
                            <i class="zmdi zmdi-search"></i>
                        </button>
                        
                        <form action="<?php echo e(route('produk')); ?>" method="get" class="formSearch">
                            <input type="hidden" value="<?php echo e(Request::get('id_lokasi')); ?>" name="id_lokasi">
                            <input autofocus class="mtext-107 cl2 size-114 plh2 p-r-15 boxSearch" type="text" name="search"
                            placeholder="Search" wire:model="search" id="search">
                            <button type="submit" id="btnSearch"></button>
                        </form>
                    </div>
                </div>
            </div>
            <div id="konten"></div>
            

            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
    var url = "<?php echo e(route('aksiSearch')); ?>?id_lokasi=<?php echo e(Request::get('id_lokasi')); ?>&kategori=<?php echo e(Request::get('kategori')); ?>"
    getSearch(url)

    function getSearch(url){
        $("#konten").load(url, "data", function (response, status, request) {
            this; // dom element                
        });
    }

$(document).on('keyup', '#search', function(){
    var s = this.value
    var url = "<?php echo e(route('aksiSearch')); ?>?id_lokasi=<?php echo e(Request::get('id_lokasi')); ?>&search="+s
    getSearch(url)
});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/produk/produk.blade.php ENDPATH**/ ?>