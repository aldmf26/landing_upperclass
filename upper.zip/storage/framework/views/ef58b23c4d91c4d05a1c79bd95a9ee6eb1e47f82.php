
<?php $__env->startSection('content'); ?>
    

    <!-- Product -->
    <div class="bg0 m-t-30 p-b-140 topproduk" style="background-color: #ECE8E1;">
        <div class="container">

            <div class="flex-w flex-sb-m p-b-52">
                <h3 class="ltext-105 cl5 txt-center respon1">
                    Best Seller
                </h3>


                <div class="flex-w flex-c-m m-tb-10">
                    


                </div>

                <!-- Search product -->
                <div class="dis-none panel-search w-full p-t-10 p-b-15">
                    <div class="bor8 dis-flex p-l-15">
                        <button class="size-113 flex-c-m fs-16 cl2 hov-cl1 trans-04">
                            <i class="zmdi zmdi-search"></i>
                        </button>
                        
                        <form action="<?php echo e(route('produk')); ?>" method="get" class="formSearch">
                            <input type="hidden" value="<?php echo e(Request::get('id_lokasi')); ?>" name="id_lokasi">
                            <input autofocus class="mtext-107 cl2 size-114 plh2 p-r-15 boxSearch" type="text" name="search"
                                placeholder="Search" wire:model="search" id="search">
                            <button type="submit" id="btnSearch"></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row isotope-grid">
                <?php
                    $bl = DB::table('tb_produk')
                                ->join('tb_kategori', 'tb_produk.id_kategori', '=', 'tb_kategori.id_kategori')
                                ->join('tb_satuan', 'tb_produk.id_satuan', '=', 'tb_satuan.id_satuan')
                                ->join('tb_harga', 'tb_produk.id_produk', '=', 'tb_harga.id_produk')
                                ->where('tb_produk.best_seller', 'ON')
                                ->groupBy('tb_harga.id_produk')
                                ->get();
                ?>
                <?php $__currentLoopData = $bl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="col-sm-6 col-md-4 col-lg-3 col-6 p-b-35 isotope-item <?php echo e(Str::lower($p->nm_kategori)); ?> listSearch">
                        <!-- Block2 -->
                        <div class="block2">
                            <div class="block2-pic hov-img0">
                                <a href="<?php echo e(route('detail', ['id_produk' => $p->id_produk])); ?>">
                                    <img src="http://127.0.0.1:1111/assets/uploads/<?php echo e($p->foto); ?>" alt="IMG-PRODUCT">
                                </a>
                            </div>

                            <div class="block2-txt flex-w flex-t p-t-14">
                                <div class="block2-txt-child1 flex-col-l ">
                                    <a href="<?php echo e(route('detail', ['id_produk' => $p->id_produk])); ?>"
                                        class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6"
                                        style="font-family: Americana-Regular; font-size: 11px;">
                                        <?php echo e(ucwords(Str::lower($p->nm_produk))); ?>

                                    </a>

                                    <span class="stext-105 cl3">
                                        <?php echo e(number_format($p->harga, 0)); ?>

                                    </span>
                                </div>


                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/bestSeller/bestSeller.blade.php ENDPATH**/ ?>