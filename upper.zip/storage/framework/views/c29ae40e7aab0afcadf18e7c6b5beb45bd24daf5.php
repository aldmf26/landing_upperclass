<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Tutorial Laravel Mail | ayongoding.com</title>
</head>
<body>
    <p>Hallo <b><?php echo e($penerima); ?></b> berikut ini adalah pesan Dari <?php echo e($email); ?>:</p>
    <table>
      <tr>
        <td>Pesan</td>
        <td>:</td>
        <td><?php echo e($msg); ?></td>
      </tr>
      
    </table>
    <p>Terimakasih <b><?php echo e($email); ?></b> telah memberi komentar.</p>
</body>
</html><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/mail/view.blade.php ENDPATH**/ ?>