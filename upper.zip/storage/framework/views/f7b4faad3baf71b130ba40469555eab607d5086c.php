
<?php $__env->startSection('content'); ?>
<div class="bg0 m-t-30 p-b-90 topproduk" style="background-color: #ECE8E1;">
    <div class="container" >
        <div class="row justify-content-center">
            <div class="col-md-8">

                <div class="card">
                    <div class="card-header">
                        <?php echo e(_('Verifiy Your Email Address')); ?>

                    </div>
                    <div class="card-body">
                        <?php if(session('resent')): ?>
                            <div class="alert alert-success">
                                <?php echo e(_('email verifikasi terkirim')); ?>

                            </div>
                        <?php endif; ?>

                        <?php echo e(_('email Anda Belum diverifikasi')); ?>, <a href="" class="btn btn-link p-0 m-0 align-bassline text-wrap">kirim ulang kode verifikasi</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/login/verify.blade.php ENDPATH**/ ?>