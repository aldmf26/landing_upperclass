
<?php $__env->startSection('content'); ?>
<style>
    .forgot:hover {
        text-decoration: underline;
    }
    .daftar:hover {
        text-decoration: underline;
    }
    .inputan {
        height: 2.8rem;
    }
    .buton {
        height: 3.5rem;
        padding-right: 40px;
        padding-left: 40px;
        background-color: #89725C;
        border: #89725C;
    }
    .buton:hover {
        background-color: #cbaa8d;
        border: 1px solid #89725C;     
    }
    .butong:hover {
        background-color: #cbaa8d;
        border: 1px solid #89725C;
    }

</style>
<div class="bg0 m-t-30 p-b-90 topproduk" style="background-color: #ECE8E1;">
    <div class="container" >
        <div class="row txt-center">
            <div class="col-xl-12 m-t-30">
                <h3 style="font-size:40px; color:#1C1A1A; font-family: Americana-Regular; margin-bottom:50px;">Login</h3>
                <?php if($pesan = Session::get('error')){ ?>
                    <h3 style="font-size:20px; color:#1C1A1A; font-family: Americana-Regular; margin-bottom:20px;"><i class="fa-solid fa-circle-exclamation text-danger"></i> Please adjust the following:</h3>
                    <h3 style="font-size:20px; text-decoration:underline; color:#ff0000; font-family: Sans-Serif; margin-bottom:50px;"><em><?php echo e($pesan); ?></em></h3>
                <?php }else{ ?>
                <?php } ?>

                <form action="<?php echo e(route('aksiLogin')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="inputan">
                    <center>
                        <div class="form-group">
                            <div class="col-lg-5">
                                <input type="email" name="email" placeholder="Email" class="form-control inputan">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-5">
                                <input type="password" name="password" placeholder="Password" class="form-control inputan">
                            </div>
                        </div>
                    </div>
                    </center>
                    <div class="form-group m-t-70">
                        
                        
                    </div>
                    <button class="btn btn-primary mt-3 mb-2 buton" type="submit">Sign in</button><br>
                </form>
                <label><a href="<?php echo e(route('register')); ?>" style="color: #89725C; white-space:nowrap;" class="txt-center daftar"> Create account</a></label>
                <hr>
                

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/login/login.blade.php ENDPATH**/ ?>