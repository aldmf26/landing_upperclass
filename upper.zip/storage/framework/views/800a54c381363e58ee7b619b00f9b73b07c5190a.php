<div class="row isotope-grid">
<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="col-sm-6 col-md-4 col-lg-3 col-6 p-b-35 isotope-item <?php echo e(Str::lower($p->nm_kategori)); ?> listSearch">
                        <!-- Block2 -->
                        <div class="block2">
                            <div class="block2-pic hov-img0">
                                <a href="<?php echo e(route('detail', ['id_produk' => $p->id_produk])); ?>">
                                    <img src="http://127.0.0.1:1111/assets/uploads/<?php echo e($p->foto); ?>" alt="IMG-PRODUCT">
                                </a>
                            </div>

                            <div class="block2-txt flex-w flex-t p-t-14">
                                <div class="block2-txt-child1 flex-col-l ">
                                    <a href="<?php echo e(route('detail', ['id_produk' => $p->id_produk])); ?>"
                                        class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6" style="font-family: Americana-Regular; font-size: 11px;">
                                        <?php echo e(ucwords(Str::lower($p->nm_produk))); ?>

                                    </a>

                                    <span class="stext-105 cl3">
                                        <?php echo e(number_format($p->harga, 0)); ?>

                                    </span>
                                </div>


                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><?php /**PATH C:\Users\User\Desktop\landing_upperclass\resources\views/produk/pr.blade.php ENDPATH**/ ?>